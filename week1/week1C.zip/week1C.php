<?php
    //create array using array() to define it as an array
    $array = array("cat", "dog", "mouse");
    //create an output using implode() function. it takes the ',' as the sepeator inbetween each element in the array.
    $output = implode (',', $array);
    //printing output of the array
    echo $output
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>
</html>